  $(document).ready(function() {

	var URL = "https://api.flickr.com/services/feeds/photos_public.gne";
	var ID = "?id=152934958@N02"; //Flickr Account ID
	var jsonFormat = "&format=json&jsoncallback=?";
	var ajaxURL = URL + ID + jsonFormat;
	
	//		$('#photos').append(ajaxURL);


    $.getJSON(ajaxURL,function(data) {
		$('h1').text(data.title);
		$.each(data.items,function(i,photo){
		var photoHTML = '<span class="image">';
		photoHTML += '<a href"' + photo.link + '">';
		photoHTML += '<img src="' +photo.media.m.replace('_m','_s') + '"></a></span>';
		$('#photos').append(photoHTML);
	});//end each
    }); // end get JSON
  }); // end ready
