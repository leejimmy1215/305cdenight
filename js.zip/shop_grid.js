
	
$(document).ready(function() {
	
	
	var user = window.localStorage.getItem("user");
	
	if (user == null || user == undefined || user == '' || user == 'null'){
		$('#username').html("Log in");
	} else {
		console.log(user);
		$('#username').html( user + " Welcome, click here to log out");
	}
	
	$('#logout').click(function(){
	if (user != "null"){
		window.localStorage.setItem("user", "null");
		$('#username').html("Log in");
		user = "null";
	FB.logout(function(response) {
  
	});
	} else{
		window.location.href = 'http://eldventure.com/PRO/login.html';
	}
		
	
	});
	
	
	
// Parse Initialize
var app_id = "MNHlwqykaB2I3pHsXAFlOoJlZ92uLggHzyPGKSVG";
var javascript_key = "29XjgrXROWLoxOU27XAltcLZPxRxBkGwGJs5yUWg";
Parse.initialize(app_id, javascript_key);
Parse.serverURL = 'https://parseapi.back4app.com';
var Product = Parse.Object.extend("Product");
query = new Parse.Query(Product);
		query.exists("objectId");
		query.find({
			success: function (Product) {
			var rate, rate2,html;
			var star = '<i class="fa fa-star"></i>';
			var nostar = '<i class="fa fa-star-o"></i>';
	
				for (var i=0; i<Product.length; i++) {
					var obj = Product[i].attributes;
					
					rate = new Array(  obj.rating + 1 ).join( star ); 
					rate2 = new Array( 5 -  obj.rating + 1 ).join( nostar ); 
					console.log(obj);
					html = 	'<li class="item col-lg-4 col-md-4 col-sm-4 col-xs-6"><div class="item-inner"><div class="item-img"><div class="item-img-info"> <a class="product-image" title="Product Title Here" href="single_product.html"> <img alt="Product Title Here" src="' + obj.img._url + '"> </a></div></div><div class="item-info"><div class="info-inner"><div class="item-title"><h6> <a title="'+obj.name+'" href="single_product.html">' +  obj.name +'</a></h6> </div><div class="item-content"><div class="rating">'+ rate + rate2 +'</div><div class="item-price"><div class="price-box"> <span class="regular-price"> <span class="price">$ ' + obj.price+'</span> </span> </div></div></div></div></div></div></li>';
			
					$('.products-grid').append(html);
					
					$("<div>", {
						class: "alert alert-success ",
						html: "<strong>Commented!</strong>"
					}).hide()
					.prependTo("#box-reviews2")
					.slideDown()
					.delay(3000)
					.slideUp();
	
				}


					
						
						
					
				
			},
			error: function (error) {
				console.log("Error: " + error.code + " " + error.message);
			}
		});
});




